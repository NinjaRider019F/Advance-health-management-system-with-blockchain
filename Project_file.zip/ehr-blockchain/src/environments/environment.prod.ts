export const environment = {
  production: true
};
export const IPFS = {
  localIPFS: 'http://127.0.0.1:5001/api/v0',
  localIPFSGet: 'http://localhost:8080/ipfs/'
}
